import ZipCode from './components/ZipCode'


function App() {
  
  return (
    <>
      <ZipCode />
    </>
  )
}

export default App
